# weather
Using the sample chapter from 'Full Stack React Native' by newline.co, I built a small weather app.  

API not added, as not in sample chapter.  https://www.newline.co/fullstack-react-native/

On the back of the above, currently undertaking 'The Complete React Native And Redux Course [2020 Edition]', by Stephen Grider, on Udemy.  So far, so good!
